<?php
// created: 2016-05-20 05:14:02
$dictionary["tog_testmodule"]["fields"]["tog_testmodule_accounts"] = array (
  'name' => 'tog_testmodule_accounts',
  'type' => 'link',
  'relationship' => 'tog_testmodule_accounts',
  'source' => 'non-db',
  'module' => 'Accounts',
  'bean_name' => 'Account',
  'side' => 'right',
  'vname' => 'LBL_TOG_TESTMODULE_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
