<?php
// created: 2016-05-20 05:14:03
$dictionary["tog_testmodule"]["fields"]["tog_testmodule_tog_company"] = array (
  'name' => 'tog_testmodule_tog_company',
  'type' => 'link',
  'relationship' => 'tog_testmodule_tog_company',
  'source' => 'non-db',
  'module' => 'tog_Company',
  'bean_name' => 'tog_Company',
  'side' => 'right',
  'vname' => 'LBL_TOG_TESTMODULE_TOG_COMPANY_FROM_TOG_COMPANY_TITLE',
);
