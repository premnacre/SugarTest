<?php
// created: 2016-05-20 05:08:08
$dictionary["tog_Company"]["fields"]["tog_company_contacts"] = array (
  'name' => 'tog_company_contacts',
  'type' => 'link',
  'relationship' => 'tog_company_contacts',
  'source' => 'non-db',
  'module' => 'Contacts',
  'bean_name' => 'Contact',
  'side' => 'right',
  'vname' => 'LBL_TOG_COMPANY_CONTACTS_FROM_CONTACTS_TITLE',
);
